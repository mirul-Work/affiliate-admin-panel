# Affiliate Admin Panel (Render Version)

## 🟢 Features
- Manual add product (Name, Price, Link)
- Auto blast semua produk ke Telegram
- Detect Chat ID function

## 🚀 Deploy to Render

1. Signup at https://render.com (Free Plan)
2. Create new Web Service
3. Connect to your GitHub repo (upload project folder)
4. Set Build & Deploy:
   - Runtime: Node.js
   - Build Command: (empty)
   - Start Command: `npm start`
5. Add Environment Variables (optional)
6. Deploy & run!

Visit your Render URL → Admin Panel ready.
